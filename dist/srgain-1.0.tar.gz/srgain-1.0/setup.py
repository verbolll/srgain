from distutils.core import setup
setup(
name="srgain",
version="1.0",
description="edited by myself",
author="verbo",
py_modules=["my_packages.base","my_packages.draw","my_packages.selectOT"]
)